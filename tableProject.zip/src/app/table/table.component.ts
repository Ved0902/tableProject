import { Component, OnInit } from '@angular/core';

export interface PeriodicElement {
  name: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    name: 'rupesh',
  },
  {
    name: 'vedant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'vedant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'sushant',
  },
  {
    name: 'vedant',
  },
  {
    name: 'vedant',
  },
  {
    name: 'vedant',
  },
  {
    name: 'vedant',
  },
  {
    name: 'vedant',
  },
  {
    name: 'rupesh',
  },
  {
    name: 'rupesh',
  },
  {
    name: 'vedant',
  },
];

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css'],
})
export class TableComponent implements OnInit {
  displayedColumns: string[] = ['name', 'noOfDuplication'];
  dataSource = ELEMENT_DATA;
  duplicateNo: any = [];
  uniqueValue: any = [];
  constructor() {}

  ngOnInit(): void {
    console.log('TableData', this.dataSource);

    this.duplicateNo = this.dataSource.filter((x) => {
      this.uniqueValue.includes(!x.name)
        ? this.uniqueValue.push(x.name)
        : this.duplicateNo.push(x.name);

      console.log('duplicateNo', this.duplicateNo);
      console.log('uniqueValue', this.uniqueValue);
    });
  }
}
