import { TestBed } from '@angular/core/testing';

import { TableserviesService } from './tableservies.service';

describe('TableserviesService', () => {
  let service: TableserviesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TableserviesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
