import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class TableserviesService {
  constructor() {}

  getTableData() {
    return;
  }
}
